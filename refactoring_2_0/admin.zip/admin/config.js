var firebaseConfig = {
    apiKey: "AIzaSyAzXHOJgiGYneya4c93f0u01roepEjYOlw",
    authDomain: "equalitech-1e0a1.firebaseapp.com",
    databaseURL: "https://equalitech-1e0a1.firebaseio.com",
    projectId: "equalitech-1e0a1",
    storageBucket: "equalitech-1e0a1.appspot.com",
    messagingSenderId: "1091916040026",
    appId: "1:1091916040026:web:4c78cd85dba18096815563"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  