// var config = {
//     apiKey: "AIzaSyC5FbbkqwZJviVmolbsBAOm-NJpq7EOxDA",
//     authDomain: "equalitech-1e0a1.firebaseapp.com",
//     databaseURL: "https://equalitech-1e0a1.firebaseio.com",
//     projectId: "equalitech-1e0a1",
//     storageBucket: "equalitech-1e0a1.appspot.com",
//     messagingSenderId: "1091916040026"
// };

const config = {
  apiKey: "AIzaSyC5FbbkqwZJviVmolbsBAOm-NJpq7EOxDA",
  authDomain: "equalitech-1e0a1.firebaseapp.com",
  databaseURL: "https://equalitech-1e0a1.firebaseio.com",
  projectId: "equalitech-1e0a1",
  storageBucket: "equalitech-1e0a1.appspot.com",
  messagingSenderId: "1091916040026",
  appId: "1:1091916040026:web:fdb8a18152b5176a"
};