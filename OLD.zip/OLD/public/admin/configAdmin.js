// Initialize Firebase
// Your web app's Firebase configuration
// var firebaseConfig = {
//   apiKey: "AIzaSyC5FbbkqwZJviVmolbsBAOm-NJpq7EOxDA",
//   authDomain: "equalitech-1e0a1.firebaseapp.com",
//   databaseURL: "https://equalitech-1e0a1.firebaseio.com",
//   projectId: "equalitech-1e0a1",
//   storageBucket: "equalitech-1e0a1.appspot.com",
//   messagingSenderId: "1091916040026",
//   appId: "1:1091916040026:web:1771b5d0c15648e1",
//   clientId: "1091916040026-nv8eveqfk4rokfoins169ethl9dsrsnj.apps.googleusercontent.com"
// };
// // Initialize Firebase
// firebase.initializeApp(firebaseConfig);

// const firebaseConfig = {
//   apiKey: "AIzaSyC5FbbkqwZJviVmolbsBAOm-NJpq7EOxDA",
//   authDomain: "equalitech-1e0a1.firebaseapp.com",
//   databaseURL: "https://equalitech-1e0a1.firebaseio.com",
//   projectId: "equalitech-1e0a1",
//   storageBucket: "equalitech-1e0a1.appspot.com",
//   messagingSenderId: "1091916040026",
//   appId: "1:1091916040026:web:8a27c3c28e07983a",
//   clientId: "1091916040026-lvq3b3i9jr4rbcgriarp4aj7vqcmsnkf.apps.googleusercontent.com"
  
// };

const firebaseConfig = {
  apiKey: "AIzaSyC5FbbkqwZJviVmolbsBAOm-NJpq7EOxDA",
  authDomain: "equalitech-1e0a1.firebaseapp.com",
  databaseURL: "https://equalitech-1e0a1.firebaseio.com",
  projectId: "equalitech-1e0a1",
  storageBucket: "equalitech-1e0a1.appspot.com",
  messagingSenderId: "1091916040026",
  appId: "1:1091916040026:web:fdb8a18152b5176a",
  clientId: "1091916040026-lvq3b3i9jr4rbcgriarp4aj7vqcmsnkf.apps.googleusercontent.com"
};